---
layout: archive
title: "Publications"
permalink: /publications/
author_profile: true
---

<ul>{% for post in site.publications reversed %}
  {% include archive-single-cv.html %}
{% endfor %}</ul>
